# Assignment given by our class teacher
